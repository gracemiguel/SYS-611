#Grace Miguel
#October 19,2021
import scipy.integrate.quadpack
import scipy.integrate.odepack
import numpy as np
import matplotlib.pyplot as plt

t = np.linspace(0,180)

def ds_dt(t,I):
    N=1600
    beta = 0.2
    return -beta*(I/N)

S = scipy.integrate.odeint(ds_dt,1,t)

def di_dt(t,S):
    gamma = (1/10)
    N=1600
    beta=0.2
    return beta*S*(I/N) - gamma*I

I = scipy.integrate.odeint(di_dt, 1, t, S)



def dr_dt(t, I):
    gamma = (1/10)
    return gamma*I


R = scipy.integrate.odeint(dr_dt, 1, t, I)

plt.figure()
plt.step(t, S, '-r', where='post', label='scipy.odeint')
plt.xlabel('Time ($t$)')
plt.ylabel('Susceptible Population ($dS/dt$)')
plt.legend(loc='best')
plt.show()


 



